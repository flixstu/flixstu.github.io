# -*- coding: utf-8 -*-
"""FlixTurkish Kodi addon - browse Turkish series from turskeserije.tv"""
import sys
import os
import json
import re
from urllib import request as urllib_request
from urllib import parse as urllib_parse

try:
    import xbmc
    import xbmcgui
    import xbmcplugin
    import xbmcaddon
    import xbmcvfs
    IN_KODI = True
except ImportError:
    IN_KODI = False

ADDON_ID = "plugin.video.flixturkish"
BASE_URL = "https://turskeserije.tv"
UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36"
TIMEOUT = 30
RECENT_LIMIT = 12


def addon():
    if IN_KODI:
        try:
            return xbmcaddon.Addon(ADDON_ID)
        except Exception:
            pass
    return None


def _translate(path):
    if IN_KODI:
        try:
            return xbmcvfs.translatePath(path)
        except Exception:
            pass
    return path


def addon_path():
    if IN_KODI:
        try:
            return _translate(addon().getAddonInfo("path"))
        except Exception:
            pass
    return os.path.dirname(os.path.abspath(__file__))


def local_art(filename):
    p = os.path.join(addon_path(), filename)
    return p if os.path.isfile(p) else ""


def profile_path():
    if IN_KODI:
        try:
            p = addon().getAddonInfo("profile")
            if p:
                p = _translate(p)
                try:
                    xbmcvfs.mkdirs(p)
                except Exception:
                    pass
                if not os.path.isdir(p):
                    try:
                        os.makedirs(p, exist_ok=True)
                    except Exception:
                        pass
                return p
        except Exception:
            pass
    d = os.path.join(os.path.dirname(os.path.abspath(__file__)), "profile")
    os.makedirs(d, exist_ok=True)
    return d


DATA_FILE = os.path.join(profile_path(), "data.json")


def load_data():
    try:
        if os.path.isfile(DATA_FILE):
            with open(DATA_FILE, "r", encoding="utf-8") as f:
                d = json.load(f)
                if isinstance(d, dict):
                    d.setdefault("recent", [])
                    d.setdefault("watched", [])
                    return d
    except Exception:
        pass
    return {"recent": [], "watched": []}


def save_data(d):
    try:
        os.makedirs(os.path.dirname(DATA_FILE), exist_ok=True)
        with open(DATA_FILE, "w", encoding="utf-8") as f:
            json.dump(d, f, ensure_ascii=False, indent=2)
    except Exception:
        pass


def log(msg):
    if IN_KODI:
        try:
            xbmc.log("[%s] %s" % (ADDON_ID, msg), xbmc.LOGINFO)
        except Exception:
            pass
    else:
        print("[%s] %s" % (ADDON_ID, msg))


def notify(message, heading="FlixTurkish"):
    if IN_KODI:
        try:
            xbmcgui.Dialog().notification(heading, message, xbmcgui.NOTIFICATION_INFO, 4000)
        except Exception:
            pass
    else:
        print("NOTIFY %s: %s" % (heading, message))


def http_get(url):
    req = urllib_request.Request(url, headers={"User-Agent": UA, "Accept": "text/html"})
    with urllib_request.urlopen(req, timeout=TIMEOUT) as resp:
        raw = resp.read()
    try:
        return raw.decode("utf-8", errors="replace")
    except Exception:
        return raw.decode("latin-1", errors="replace")


def clean_html(s):
    s = re.sub(r"<[^>]+>", "", s or "")
    s = s.replace("&amp;", "&").replace("&quot;", '"').replace("&#039;", "'").replace("&nbsp;", " ")
    return s.strip()


def build_url(params):
    base = sys.argv[0] if (IN_KODI and len(sys.argv) > 0) else "plugin://%s/" % ADDON_ID
    return base + "?" + urllib_parse.urlencode(params)


def get_params():
    if not IN_KODI:
        return {}
    qs = sys.argv[2] if len(sys.argv) > 2 else ""
    if qs.startswith("?"):
        qs = qs[1:]
    return dict(urllib_parse.parse_qsl(qs))


def set_common_art(li, thumb=""):
    art = {}
    if thumb:
        art["thumb"] = thumb
        art["icon"] = thumb
        art["poster"] = thumb
    if art:
        li.setArt(art)


def set_container_fanart(handle):
    fan = local_art("fanart.jpg")
    if fan:
        try:
            xbmcplugin.setPluginFanart(handle, fan)
        except Exception:
            pass


def parse_search_results(html):
    results = []
    seen = set()
    for m in re.finditer(r'<div\s+data-movie-id="(\d+)"\s+class="ml-item">(.*?</a>)\s*</div>', html, re.S):
        block = m.group(2)
        u = re.search(r'<a\s+href="([^"]+)"', block)
        img = re.search(r'<img[^>]*src="([^"]+)"', block)
        title = re.search(r'<h2>(.*?)</h2>', block, re.S)
        if not u:
            continue
        url = u.group(1)
        if url in seen:
            continue
        seen.add(url)
        thumb = img.group(1) if img else ""
        name = clean_html(title.group(1)) if title else url.rstrip("/").split("/")[-1]
        results.append({"url": url, "thumb": thumb, "title": name})
    # fallback: broader
    if not results:
        for m in re.finditer(r'class="ml-item">(.*?</a>)\s*</div>', html, re.S):
            block = m.group(1)
            u = re.search(r'<a\s+href="([^"]+)"', block)
            img = re.search(r'<img[^>]*src="([^"]+)"', block)
            title = re.search(r'<h2>(.*?)</h2>', block, re.S)
            if not u:
                continue
            url = u.group(1)
            if url in seen:
                continue
            seen.add(url)
            thumb = img.group(1) if img else ""
            name = clean_html(title.group(1)) if title else url.rstrip("/").split("/")[-1]
            results.append({"url": url, "thumb": thumb, "title": name})
    return results


def parse_search_results_1turske9(html):
    results = []
    seen = set()
    for m in re.finditer(r'<div class="item[^"]*"[^>]*>(.*?</h3>)', html, re.S):
        block = m.group(1)
        u = re.search(r'<a\s+href="([^"]+)"[^>]*class="poster"', block)
        if not u:
            u = re.search(r'<a\s+href="([^"]+)"', block)
        img = re.search(r'<img[^>]*src="([^"]+)"', block)
        title = re.search(r'<a[^>]*class="title"[^>]*>(.*?)</a>', block, re.S)
        if not u:
            continue
        url = u.group(1)
        if url in seen:
            continue
        seen.add(url)
        thumb = img.group(1) if img else ""
        name = clean_html(title.group(1)) if title else url.rstrip("/").split("/")[-1]
        results.append({"url": url, "thumb": thumb, "title": name})
    return results
    eps = []
    seen = set()
    for m in re.finditer(r'<a[^>]*class="episodi?"[^>]*href="([^"]+)"[^>]*>(.*?)</a>', html, re.S):
        url = m.group(1)
        if url in seen:
            continue
        seen.add(url)
        label = clean_html(re.sub(r'<span[^>]*>.*?</span>', '', m.group(2), flags=re.S))
        if not label:
            label = url.rstrip("/").split("/")[-1]
        eps.append({"url": url, "title": label})
    return eps


def parse_episodes(html):
    eps = []
    seen = set()
    for m in re.finditer(r'<a[^>]*class="episodi?"[^>]*href="([^"]+)"[^>]*>(.*?)</a>', html, re.S):
        url = m.group(1)
        if url in seen:
            continue
        seen.add(url)
        label = clean_html(re.sub(r'<span[^>]*>.*?</span>', '', m.group(2), flags=re.S))
        if not label:
            label = url.rstrip("/").split("/")[-1]
        eps.append({"url": url, "title": label})
    return eps


def parse_host_links(html):
    links = []
    seen = set()
    for m in re.finditer(r'<a[^>]*href="(https?://[^"]+)"[^>]*>\s*Server\s*\d+', html, re.I | re.S):
        u = m.group(1)
        if u not in seen:
            seen.add(u)
            links.append(u)
    # fallback any vidmoly/voe/srborikoa links
    if not links:
        for m in re.finditer(r'href="(https?://[^"]*(?:vidmoly|voe\.sx|srborikoa)[^"]*)"', html, re.I):
            u = m.group(1)
            if u not in seen:
                seen.add(u)
                links.append(u)
    return links


def parse_og(html, key):
    m = re.search(r'<meta\s+property="og:%s"\s+content="([^"]*)"' % key, html, re.I)
    if m:
        return m.group(1)
    m = re.search(r'<meta\s+content="([^"]*)"\s+property="og:%s"' % key, html, re.I)
    if m:
        return m.group(1)
    return ""


def add_recent(title, url, thumb):
    data = load_data()
    recent = data.get("recent", [])
    # remove existing
    recent = [r for r in recent if r.get("url") != url]
    recent.insert(0, {"title": title, "url": url, "thumb": thumb})
    recent = recent[:RECENT_LIMIT]
    data["recent"] = recent
    save_data(data)


def is_watched(url):
    data = load_data()
    return url in (data.get("watched") or [])


def mark_watched(url):
    data = load_data()
    watched = data.get("watched") or []
    if url not in watched:
        watched.append(url)
    data["watched"] = watched
    save_data(data)


# ------------------------------------------------------------------ listing

def root_listing(handle):
    xbmcplugin.setPluginCategory(handle, "FlixTurkish")
    xbmcplugin.setContent(handle, "videos")
    set_container_fanart(handle)
    items = []

    li_search = xbmcgui.ListItem(label="Search...")
    li_search.setArt({"icon": "DefaultAddonsSearch.png", "thumb": "DefaultAddonsSearch.png",
                      "poster": "DefaultAddonsSearch.png"})
    li_search.setInfo("video", {"title": "Search...", "plot": "Search Turkish series."})
    items.append((build_url({"action": "search"}), li_search, True))

    data = load_data()
    for r in data.get("recent", []):
        li = xbmcgui.ListItem(label=r.get("title", "Series"))
        set_common_art(li, thumb=r.get("thumb", ""))
        li.setInfo("video", {"title": r.get("title", ""), "plot": "Recently opened series."})
        items.append((build_url({"action": "show", "url": r.get("url", ""), "title": r.get("title", ""),
                                 "thumb": r.get("thumb", "")}), li, True))

    xbmcplugin.addDirectoryItems(handle, items, len(items))
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_UNSORTED)
    xbmcplugin.endOfDirectory(handle)


def do_search(handle):
    kb = xbmcgui.Dialog()
    query = kb.input("Search series")
    if not query:
        return
    query = query.strip()
    if not query:
        return
    list_search(handle, query)


def list_search(handle, query):
    xbmcplugin.setPluginCategory(handle, 'Search: "%s"' % query)
    xbmcplugin.setContent(handle, "videos")
    set_container_fanart(handle)

    # Fetch from both sources
    all_results = []
    seen_titles = set()
    sources = [
        (BASE_URL, parse_search_results),
        ("https://1turske9.com", parse_search_results_1turske9),
    ]
    for base, parser in sources:
        url = base + "/?s=" + urllib_parse.quote(query)
        try:
            html = http_get(url)
        except Exception as e:
            log("search failed (%s): %s" % (base, e))
            continue
        for r in parser(html):
            key = re.sub(r"\s+", " ", r["title"]).strip().lower()
            if key in seen_titles:
                continue
            seen_titles.add(key)
            all_results.append(r)

    if not all_results:
        notify("No results found.")
        xbmcplugin.endOfDirectory(handle, succeeded=True)
        return

    items = []
    for r in all_results:
        li = xbmcgui.ListItem(label=r["title"])
        set_common_art(li, thumb=r["thumb"])
        li.setInfo("video", {"title": r["title"], "mediatype": "video"})
        items.append((build_url({"action": "show", "url": r["url"], "title": r["title"],
                                 "thumb": r["thumb"]}), li, True))

    xbmcplugin.addDirectoryItems(handle, items, len(items))
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_LABEL)
    xbmcplugin.endOfDirectory(handle)


def list_episodes(handle, url, title="", thumb=""):
    xbmcplugin.setPluginCategory(handle, title or "Series")
    xbmcplugin.setContent(handle, "episodes")
    set_container_fanart(handle)

    try:
        html = http_get(url)
    except Exception as e:
        log("show failed: %s" % e)
        notify("Could not load series: %s" % e)
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    if not title:
        title = parse_og(html, "title") or url.rstrip("/").split("/")[-1]
    if not thumb:
        thumb = parse_og(html, "image")
    # clean title (remove site suffix)
    title = title.split("|")[0].strip()

    add_recent(title, url, thumb)

    eps = parse_episodes(html)
    if not eps:
        notify("No episodes found.")
        xbmcplugin.endOfDirectory(handle, succeeded=True)
        return

    items = []

    # Choose episode by number at the top
    li_choose = xbmcgui.ListItem(label="Choose episode...")
    set_common_art(li_choose, thumb=thumb or local_art("icon.jpg"))
    li_choose.setInfo("video", {"title": "Choose episode...", "plot": "Enter episode number."})
    items.append((build_url({"action": "choose", "url": url, "title": title, "thumb": thumb}), li_choose, False))

    for ep in eps:
        ep_title = ep["title"]
        watched = is_watched(ep["url"])
        label = ("[W] " if watched else "") + ep_title
        li = xbmcgui.ListItem(label=label)
        set_common_art(li, thumb=thumb)
        info = {"title": ep_title, "mediatype": "episode", "tvshowtitle": title}
        if watched:
            info["playcount"] = 1
        try:
            li.setInfo("video", info)
        except Exception:
            pass
        li.setProperty("IsPlayable", "true")
        items.append((build_url({"action": "play", "url": ep["url"], "show": title,
                                 "title": ep_title, "thumb": thumb}), li, False))

    xbmcplugin.addDirectoryItems(handle, items, len(items))
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_UNSORTED)
    xbmcplugin.endOfDirectory(handle)


def play_episode(handle, params):
    url = params.get("url", "")
    title = params.get("title", "Episode")
    thumb = params.get("thumb", "")
    show = params.get("show", "")
    if not url:
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return

    try:
        html = http_get(url)
    except Exception as e:
        log("episode load failed: %s" % e)
        notify("Could not load episode: %s" % e)
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return

    if not title:
        title = parse_og(html, "title") or url.rstrip("/").split("/")[-1]
    title = title.split("|")[0].strip()
    if not thumb:
        thumb = parse_og(html, "image")

    host_links = parse_host_links(html)
    log("host_links: %s" % host_links)
    try:
        dbg = os.path.join(profile_path(), "debug.txt")
        with open(dbg, "w", encoding="utf-8") as f:
            f.write("host_links: %s\n" % host_links)
    except Exception:
        pass
    stream_url = None
    resolve_results = []
    try:
        import resolveurl
        for hl in host_links:
            try:
                hmf = resolveurl.HostedMediaFile(url=hl)
                su = hmf.resolve() if hmf else False
                resolve_results.append((hl, str(su)))
                log("resolve %s -> %s" % (hl, su))
                if su and isinstance(su, str):
                    stream_url = su
                    break
            except Exception as e:
                resolve_results.append((hl, "ERR %s" % e))
                log("resolve failed %s: %s" % (hl, e))
    except Exception as e:
        resolve_results.append(("import", "ERR %s" % e))
        log("resolveurl import failed: %s" % e)
        notify("ResolveURL import failed: %s" % e)

    try:
        dbg = os.path.join(profile_path(), "debug.txt")
        with open(dbg, "a", encoding="utf-8") as f:
            f.write("resolve_results: %s\n" % resolve_results)
            f.write("stream_url: %s\n" % stream_url)
    except Exception:
        pass

    if not stream_url and host_links:
        # do not fall back to download pages; they are not playable
        stream_url = None

    if not stream_url:
        msg = "Resolve failed"
        if resolve_results:
            msg += ": " + str(resolve_results[0])
        notify(msg, heading=title)
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return

    notify("Playing: %s" % (stream_url[:60]), heading=title)

    mark_watched(url)

    li = xbmcgui.ListItem(label=title, path=stream_url)
    li.setProperty("IsPlayable", "true")
    set_common_art(li, thumb=thumb or local_art("icon.jpg"))
    try:
        tag = li.getVideoInfoTag()
        tag.setTitle(title)
        if show:
            tag.setTvShowTitle(show)
    except Exception:
        pass
    xbmcplugin.setResolvedUrl(handle, True, li)


def do_choose(handle, params):
    url = params.get("url", "")
    title = params.get("title", "")
    thumb = params.get("thumb", "")
    if not url:
        return
    kb = xbmcgui.Dialog()
    num = kb.input("Episode number")
    if not num:
        return
    num = num.strip()
    if not num.isdigit():
        notify("Invalid number")
        return
    n = int(num)
    try:
        html = http_get(url)
    except Exception as e:
        notify("Could not load series: %s" % e)
        return
    if not title:
        title = parse_og(html, "title") or url.rstrip("/").split("/")[-1]
    title = title.split("|")[0].strip()
    if not thumb:
        thumb = parse_og(html, "image")

    eps = parse_episodes(html)
    target = None
    for ep in eps:
        m = re.search(r'(\d+)', ep["title"])
        if m and int(m.group(1)) == n:
            target = ep
            break
    if target is None and 1 <= n <= len(eps):
        target = eps[n - 1]
    if target is None:
        notify("Episode not found.")
        return
    play_episode(handle, {"url": target["url"], "title": target["title"], "thumb": thumb, "show": title})


def router():
    if not IN_KODI:
        print("FlixTurkish: not running inside Kodi.")
        return
    handle = int(sys.argv[1]) if len(sys.argv) > 1 else -1
    params = get_params()
    action = params.get("action", "")

    if action == "search":
        do_search(handle)
    elif action == "show":
        list_episodes(handle, params.get("url", ""), params.get("title", ""), params.get("thumb", ""))
    elif action == "choose":
        do_choose(handle, params)
    elif action == "listing":
        list_search(handle, params.get("search", ""))
    else:
        root_listing(handle)


if __name__ == "__main__":
    router()
