import xbmcaddon
import base64

MainBase = (base64.b64decode('WVVoU01HTklUVFpNZVRsellWaGFiR1JJV25KaU1sSndZekpXZVZsdGJHaE1iVTUyWWxN').decode() + base64.b64decode('NWFGcEhVblppYm1oMFlrTTVjbGxYTldoaVIydDJZVEk1YTJGWVRubFpiV3h4V1ZNMWQyRklRVDA9').decode())

MainBase = base64.b64decode(MainBase).decode()
MainBase = base64.b64decode(MainBase).decode()

addon = xbmcaddon.Addon('plugin.video.livetvSerbia')
