# -*- coding: utf-8 -*-
"""FlixTV by FlixStudios - Kodi 21 Omega video plugin.

Flow:
  Root -> All Channels, Search, then countries
  Country -> list all channels in that country
  Channel -> resolve play URL to direct stream and play in Kodi
"""
import sys
import json
import time
import datetime
import os
from urllib import request as urllib_request
from urllib import parse as urllib_parse

try:
    import xbmc
    import xbmcgui
    import xbmcplugin
    import xbmcaddon
    IN_KODI = True
except ImportError:
    # Allows syntax-checking / running outside Kodi
    IN_KODI = False

ADDON_ID = "plugin.video.flixtv"
DEVELOPER = "FlixStudios"
BASE_URL = "https://kool.to"
CATALOG_URL = BASE_URL + "/mediahubmx-catalog.json"
RESOLVE_URL = BASE_URL + "/mediahubmx-resolve.json"

UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36 Kodi-FlixTV/1.1.0"

# Fallback if the live API is unreachable
FALLBACK_GROUPS = [
    "Albania", "Arabia", "Balkans", "Bulgaria", "Croatia",
    "France", "France Sport", "Germany", "Italy", "Netherlands",
    "Poland", "Portugal", "Romania", "Russia", "Spain",
    "Turkey", "United Kingdom",
]

# Flags are bundled in resources/flags/ - every PNG is 320x240 (identical size)
COUNTRY_FLAG_FILE = {
    "Albania": "albania.png",
    "Arabia": "arabia.png",
    "Balkans": "balkans.png",
    "Bulgaria": "bulgaria.png",
    "Croatia": "croatia.png",
    "France": "france.png",
    "France Sport": "france_sport.png",
    "Germany": "germany.png",
    "Italy": "italy.png",
    "Netherlands": "netherlands.png",
    "Poland": "poland.png",
    "Portugal": "portugal.png",
    "Romania": "romania.png",
    "Russia": "russia.png",
    "Spain": "spain.png",
    "Turkey": "turkey.png",
    "United Kingdom": "united_kingdom.png",
}

TIMEOUT = 20


def addon_path():
    if IN_KODI:
        try:
            return xbmcaddon.Addon(ADDON_ID).getAddonInfo("path")
        except Exception:
            pass
    return os.path.dirname(os.path.abspath(__file__))


def local_art(filename):
    p = os.path.join(addon_path(), filename)
    return p if os.path.isfile(p) else ""


def flag_path(country):
    fname = COUNTRY_FLAG_FILE.get(country, "")
    if not fname:
        return ""
    return local_art(os.path.join("resources", "flags", fname))


def addon_icon():
    return local_art("icon.jpg")


def addon_fanart():
    return local_art("fanart.jpg")


def log(msg):
    if IN_KODI:
        xbmc.log("[%s] %s" % (ADDON_ID, msg), xbmc.LOGDEBUG)
    else:
        print("[%s] %s" % (ADDON_ID, msg))


def notify(message, heading="FlixTV"):
    if IN_KODI:
        xbmcgui.Dialog().notification(heading, message, xbmcgui.NOTIFICATION_WARNING, 5000)
    else:
        print("NOTIFY %s: %s" % (heading, message))


def api_post(url, payload):
    """POST JSON dict, return decoded JSON. Raises on error."""
    data = json.dumps(payload).encode("utf-8")
    req = urllib_request.Request(
        url,
        data=data,
        headers={
            "Content-Type": "application/json; charset=utf-8",
            "User-Agent": UA,
            "Origin": BASE_URL,
            "Referer": BASE_URL + "/live",
            "Accept": "application/json",
        },
        method="POST",
    )
    with urllib_request.urlopen(req, timeout=TIMEOUT) as resp:
        raw = resp.read().decode("utf-8", errors="replace")
    obj = json.loads(raw)
    if isinstance(obj, dict) and obj.get("error"):
        raise Exception(obj["error"])
    return obj


def catalog_request(group="", search="", sort="name", cursor=None):
    filt = {"group": group} if group else {}
    payload = {
        "language": "de",
        "region": "DE",
        "catalogId": "iptv",
        "id": "",
        "adult": False,
        "search": (search or "").strip(),
        "sort": sort,
        "filter": filt,
        "cursor": cursor,
    }
    return api_post(CATALOG_URL, payload)


def normalize_channel(item):
    if not isinstance(item, dict):
        return None
    ids = item.get("ids") or {}
    cid = ids.get("id")
    if cid is None:
        return None
    cid = str(cid)
    play_url = item.get("url") or ""
    name = item.get("name") or cid
    country = item.get("group") or ""
    logo = item.get("logo") or ""
    epg = item.get("epg") if isinstance(item.get("epg"), list) else None
    return {
        "id": cid,
        "name": name,
        "country": country,
        "logo": logo,
        "play_url": play_url,
        "epg": epg,
    }


def get_groups():
    """Fetch category list (countries)."""
    try:
        data = catalog_request(group="", search="", sort="trending-region", cursor=None)
        features = data.get("features") or {}
        for f in features.get("filter") or []:
            if isinstance(f, dict) and f.get("id") == "group":
                values = [str(v) for v in (f.get("values") or []) if str(v).strip()]
                if values:
                    return sorted(values, key=lambda s: s.lower())
        seen = []
        for it in data.get("items") or []:
            g = (it.get("group") or "").strip()
            if g and g not in seen:
                seen.append(g)
        if seen:
            return sorted(seen, key=lambda s: s.lower())
    except Exception as e:
        log("get_groups failed: %s" % e)
    return list(FALLBACK_GROUPS)


def get_all_channels(group="", search="", sort="name", max_pages=20):
    """Fetch ALL channels (handles cursor pagination).

    NOTE: global search (no group) only returns results with
    sort='trending-region', so force that sort whenever a
    search query is present. That was the broken-search bug.
    """
    if (search or "").strip():
        sort = "trending-region"
    channels = []
    seen_ids = set()
    cursor = None
    for _ in range(max_pages):
        data = catalog_request(group=group, search=search, sort=sort, cursor=cursor)
        items = data.get("items") or []
        for it in items:
            ch = normalize_channel(it)
            if ch and ch["id"] not in seen_ids:
                seen_ids.add(ch["id"])
                channels.append(ch)
        cursor = data.get("nextCursor")
        if cursor is None:
            break
        if not items:
            break
    return channels


def resolve_channel(play_url):
    """Resolve play URL -> direct stream URL (usually HLS)."""
    if not play_url:
        raise Exception("Missing channel URL")
    payload = {"language": "de", "region": "DE", "url": play_url}
    data = api_post(RESOLVE_URL, payload)
    if isinstance(data, list):
        if not data:
            raise Exception("Empty resolve response")
        data = data[0]
    if not isinstance(data, dict) or not data.get("url"):
        raise Exception("Channel could not be resolved")
    return data["url"]


# ------------------------------------------------------------------ EPG

def get_epg_now_next(epg):
    """Return (now_entry, next_entry) based on current time. Entries: {start, stop, name}."""
    if not epg:
        return None, None
    try:
        now = int(time.time())
        ordered = sorted([e for e in epg if isinstance(e, dict)], key=lambda e: e.get("start", 0) or 0)
        now_e = None
        next_e = None
        for e in ordered:
            s = e.get("start")
            t = e.get("stop")
            if s is None or t is None:
                continue
            try:
                s = int(s)
                t = int(t)
            except Exception:
                continue
            if s <= now <= t:
                now_e = e
            elif s > now and next_e is None:
                next_e = e
                if now_e is not None:
                    break
        if now_e is None:
            # nothing airing right now: take first upcoming as next
            for e in ordered:
                try:
                    if int(e.get("stop", 0)) > now:
                        next_e = next_e or e
                        break
                except Exception:
                    continue
        return now_e, next_e
    except Exception:
        return None, None


def fmt_time(ts):
    try:
        return datetime.datetime.fromtimestamp(int(ts)).strftime("%H:%M")
    except Exception:
        return ""


def format_epg_plot(epg):
    """Build a readable plot: NOW / NEXT / upcoming."""
    if not epg:
        return ""
    try:
        now_e, next_e = get_epg_now_next(epg)
        lines = []
        if now_e:
            s = fmt_time(now_e.get("start"))
            t = fmt_time(now_e.get("stop"))
            lines.append("Now (%s-%s): %s" % (s, t, now_e.get("name") or ""))
        if next_e:
            s = fmt_time(next_e.get("start"))
            t = fmt_time(next_e.get("stop"))
            lines.append("Next (%s-%s): %s" % (s, t, next_e.get("name") or ""))
        # plus up to 2 more upcoming for the info dialog
        now = int(time.time())
        ordered = sorted([e for e in epg if isinstance(e, dict)], key=lambda e: e.get("start", 0) or 0)
        extra = 0
        for e in ordered:
            if e is now_e or e is next_e:
                continue
            try:
                if int(e.get("stop", 0)) <= now:
                    continue
            except Exception:
                continue
            name = e.get("name") or ""
            if not name:
                continue
            lines.append("%s-%s: %s" % (fmt_time(e.get("start")), fmt_time(e.get("stop")), name))
            extra += 1
            if extra >= 2:
                break
        return "\n".join([l for l in lines if l.strip()])
    except Exception:
        return ""


def channel_fallback_icon(channel=None):
    """Every channel uses the FlixTV icon."""
    return addon_icon()


# ------------------------------------------------------------------ routing

def build_url(params):
    base = sys.argv[0] if len(sys.argv) > 0 else "plugin://%s/" % ADDON_ID
    return base + "?" + urllib_parse.urlencode(params)


def get_params():
    qs = sys.argv[2] if len(sys.argv) > 2 else ""
    if qs.startswith("?"):
        qs = qs[1:]
    return dict(urllib_parse.parse_qsl(qs))


def set_common_art(li, thumb=""):
    # Item art only (thumb/icon/poster). Do NOT put fanart on items:
    # skins like Arctic Horizon render item fanart as the tile, which
    # would show the FlixTV fanart instead of the country flags.
    # The listing background is set once per directory via
    # set_container_fanart() below.
    art = {}
    if thumb:
        art["thumb"] = thumb
        art["icon"] = thumb
        art["poster"] = thumb
    if art:
        li.setArt(art)


def set_container_fanart(handle):
    fan = addon_fanart()
    if fan:
        try:
            xbmcplugin.setPluginFanart(handle, fan)
        except Exception:
            pass


def list_categories(handle):
    xbmcplugin.setPluginCategory(handle, "FlixTV")
    xbmcplugin.setContent(handle, "videos")
    set_container_fanart(handle)

    try:
        groups = get_groups()
    except Exception as e:
        log("list_categories error: %s" % e)
        notify("Could not load categories: %s" % e)
        groups = list(FALLBACK_GROUPS)

    icon = addon_icon()
    items = []

    # 1) All Channels at the very top
    li_all = xbmcgui.ListItem(label="All Channels")
    set_common_art(li_all, thumb=icon)
    li_all.setInfo("video", {"title": "All Channels", "plot": "Browse every live channel."})
    items.append((build_url({"action": "listing", "country": ""}), li_all, True))

    # 2) Search right after All Channels
    li_search = xbmcgui.ListItem(label="Search...")
    li_search.setArt({"icon": "DefaultAddonsSearch.png", "thumb": "DefaultAddonsSearch.png",
                      "poster": "DefaultAddonsSearch.png"})
    li_search.setInfo("video", {"title": "Search...", "plot": "Search all channels by name."})
    items.append((build_url({"action": "search"}), li_search, True))

    # 3) Countries with their flag (all flags are the same 320x240 size)
    for g in groups:
        li = xbmcgui.ListItem(label=g)
        set_common_art(li, thumb=flag_path(g) or icon)
        li.setInfo("video", {"title": g, "plot": "Live channels from %s." % g})
        items.append((build_url({"action": "listing", "country": g}), li, True))

    xbmcplugin.addDirectoryItems(handle, items, len(items))
    # IMPORTANT: unsorted only, so our order (All, Search, countries) is kept.
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_UNSORTED)
    xbmcplugin.endOfDirectory(handle)


def list_channels(handle, country="", search=""):
    title = country if country else "All Channels"
    if search:
        title += ' - "%s"' % search
    xbmcplugin.setPluginCategory(handle, title)
    xbmcplugin.setContent(handle, "videos")
    set_container_fanart(handle)

    try:
        channels = get_all_channels(group=country, search=search, sort="name")
    except Exception as e:
        log("list_channels error: %s" % e)
        notify("Could not load channels: %s" % e)
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    if not channels:
        notify("No channels found.")
        xbmcplugin.endOfDirectory(handle, succeeded=True)
        return

    channels.sort(key=lambda c: c["name"].lower())

    items = []
    for ch in channels:
        now_e, next_e = get_epg_now_next(ch.get("epg"))
        label = ch["name"]
        li = xbmcgui.ListItem(label=label)
        li.setProperty("IsPlayable", "true")

        thumb = channel_fallback_icon(ch)
        set_common_art(li, thumb=thumb)

        plot = format_epg_plot(ch.get("epg"))
        if not plot:
            plot = "Live stream."
        tagline = ""
        if now_e and now_e.get("name"):
            tagline = "Now: %s" % now_e.get("name")
        elif next_e and next_e.get("name"):
            tagline = "Next: %s" % next_e.get("name")
        info = {"title": label, "plot": plot, "mediatype": "video"}
        if tagline:
            info["tagline"] = tagline
        try:
            li.setInfo("video", info)
        except Exception:
            pass
        try:
            tag = li.getVideoInfoTag()
            tag.setTitle(label)
            tag.setPlot(plot)
            if tagline:
                try:
                    tag.setTagLine(tagline)
                except Exception:
                    pass
            # expose EPG times when available
            if now_e:
                try:
                    tag.setFirstAired(datetime.datetime.fromtimestamp(int(now_e.get("start"))).strftime("%Y-%m-%d"))
                except Exception:
                    pass
        except Exception:
            pass
        url = build_url({
            "action": "play",
            "id": ch["id"],
            "name": label,
            "playurl": ch["play_url"],
            "logo": ch["logo"] or "",
            "country": ch["country"] or "",
        })
        items.append((url, li, False))

    xbmcplugin.addDirectoryItems(handle, items, len(items))
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_LABEL)
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_UNSORTED)
    xbmcplugin.endOfDirectory(handle)


def do_search(handle):
    kb = xbmcgui.Keyboard("", "Search channels")
    kb.doModal()
    if not kb.isConfirmed():
        return
    query = kb.getText().strip()
    if not query:
        return
    list_channels(handle, country="", search=query)


def play_channel(handle, params):
    name = params.get("name", "Channel")
    play_url = params.get("playurl", "")
    logo = params.get("logo", "")
    country = params.get("country", "")
    cid = params.get("id", "")

    if not play_url and cid:
        play_url = BASE_URL + "/kool-iptv/play/" + cid

    # Re-fetch EPG for the info dialog when playing from a listing is not possible;
    # we already have logo/country from the listing URL for fallback art.
    try:
        stream_url = resolve_channel(play_url)
    except Exception as e:
        log("resolve failed for %s: %s" % (name, e))
        notify("Stream unavailable: %s" % e, heading=name)
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return

    log("Playing %s" % name)
    li = xbmcgui.ListItem(label=name, path=stream_url)
    li.setProperty("IsPlayable", "true")
    set_common_art(li, thumb=addon_icon())
    try:
        has_ia = xbmc.getCondVisibility("System.HasAddon(inputstream.adaptive)")
    except Exception:
        has_ia = True
    low = stream_url.lower()
    is_hls = ".m3u8" in low or "m3u8" in low
    if has_ia and is_hls:
        li.setProperty("inputstream", "inputstream.adaptive")
        li.setProperty("inputstream.adaptive.manifest_type", "hls")
        li.setMimeType("application/x-mpegURL")
        li.setContentLookup(False)
    try:
        tag = li.getVideoInfoTag()
        tag.setTitle(name)
    except Exception:
        pass
    xbmcplugin.setResolvedUrl(handle, True, li)


def router():
    if not IN_KODI:
        print("FlixTV: not running inside Kodi (import xbmc failed). Nothing to route.")
        return
    handle = int(sys.argv[1]) if len(sys.argv) > 1 else -1
    params = get_params()
    action = params.get("action", "")

    if action == "listing":
        list_channels(handle, country=params.get("country", ""), search=params.get("search", ""))
    elif action == "search":
        do_search(handle)
    elif action == "play":
        play_channel(handle, params)
    else:
        list_categories(handle)


if __name__ == "__main__":
    router()
