# -*- coding: utf-8 -*-
import sys
import json
import ast
import urllib.parse
import urllib.request
import re
import os
import time

import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs

ADDON_HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]
CONFIG_URL = "https://amkokodi.com/amko/config.json"
ART_ICON = "https://amkokodi.com/repo/icon.jpg"
ART_FANART = "https://amkokodi.com/repo/fanart.png"
ART_BANNER = "https://amkokodi.com/repo/banner.jpg"
ART_CLEARLOGO = "https://amkokodi.com/repo/clearlogo.png"
CONFIG_TTL = 300  # 5 minuta cache (manje za debugging)

# Local addon paths
ADDON = xbmcaddon.Addon()
ADDON_PATH = ADDON.getAddonInfo("path")
LOCAL_ICON = os.path.join(ADDON_PATH, "icon.jpg")
LOCAL_FANART = os.path.join(ADDON_PATH, "fanart.jpg")
PROFILE_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
CACHE_FILE = os.path.join(PROFILE_PATH, "config_cache.json")
LOG_FILE = os.path.join(PROFILE_PATH, "amko_debug.log")
CUSTOM_FILE = os.path.join(PROFILE_PATH, "custom_sources.json")

# -------------------------------------------------
# DEBUG LOGGING - sprema greške u datoteku na TV-u
# -------------------------------------------------
def debug_log(msg, level="INFO"):
    """Sprema log u datoteku i u Kodi log"""
    timestamp = time.strftime("%Y-%m-%d %H:%M:%S")
    log_msg = f"[{timestamp}] [{level}] {msg}"
    
    # Kodi log
    try:
        log_level = xbmc.LOGINFO if level == "INFO" else xbmc.LOGERROR if level == "ERROR" else xbmc.LOGWARNING
        xbmc.log(log_msg, log_level)
    except Exception:
        pass
    
    # File log
    try:
        if not xbmcvfs.exists(PROFILE_PATH):
            xbmcvfs.mkdirs(PROFILE_PATH)
        
        # Čuva samo zadnjih 50 linija za smanjeću veličinu
        f = xbmcvfs.File(LOG_FILE, "a")
        try:
            f.write((log_msg + "\n").encode("utf-8"))
        finally:
            f.close()
    except Exception as e:
        pass

def get_debug_log():
    """Čita debug log"""
    try:
        if xbmcvfs.exists(LOG_FILE):
            f = xbmcvfs.File(LOG_FILE)
            try:
                data = f.read()
                return data.decode("utf-8", "ignore") if isinstance(data, bytes) else data
            finally:
                f.close()
    except Exception:
        pass
    return "Nema log podataka"

# -------------------------------------------------
# ART helpers
# -------------------------------------------------
def apply_art(li):
    icon_path = ART_ICON
    fanart_path = ART_FANART
    try:
        if xbmcvfs.exists(LOCAL_ICON):
            icon_path = LOCAL_ICON
        if xbmcvfs.exists(LOCAL_FANART):
            fanart_path = LOCAL_FANART
    except Exception:
        pass

    li.setArt({
        "icon": icon_path,
        "thumb": icon_path,
        "poster": icon_path,
        "banner": ART_BANNER,
        "clearlogo": ART_CLEARLOGO,
        "fanart": fanart_path,
        "landscape": fanart_path,
    })
    li.setProperty("fanart_image", fanart_path)

# -------------------------------------------------
# HTTP - xbmcvfs sa fallback
# -------------------------------------------------
def http_get(url, headers=None):
    """Koristi xbmcvfs za HTTP zahtjeve - kompatibilno sa Android/iOS/Linux/Windows"""
    debug_log(f"HTTP GET: {url}")
    xbmc.log(f"[AmKo] HTTP GET: {url}", xbmc.LOGINFO)
    
    # Pokušaj 1: xbmcvfs sa headerima (Kodi format)
    if headers:
        try:
            header_parts = []
            for k, v in headers.items():
                header_parts.append(f"{k}={urllib.parse.quote(str(v))}")
            url_with_headers = url + "|" + "&".join(header_parts)
            
            xbmc.log(f"[AmKo] Pokusaj 1: xbmcvfs sa headerima", xbmc.LOGINFO)
            f = xbmcvfs.File(url_with_headers)
            try:
                data = f.read()
            finally:
                f.close()
            
            if data and len(data) > 0:
                result = data.decode("utf-8", "ignore") if isinstance(data, bytes) else data
                msg = f"HTTP uspjesno (sa headerima) - duzina: {len(result)} bytes"
                xbmc.log(f"[AmKo] {msg}", xbmc.LOGINFO)
                debug_log(msg)
                return result
        except Exception as e:
            msg = f"Pokusaj 1 neuspio: {str(e)}"
            xbmc.log(f"[AmKo] {msg}", xbmc.LOGWARNING)
            debug_log(msg, "WARN")
    
    # Pokušaj 2: xbmcvfs BEZ headera (jednostavniji pristup)
    try:
        debug_log("Pokusaj 2: xbmcvfs BEZ headera")
        xbmc.log(f"[AmKo] Pokusaj 2: xbmcvfs BEZ headera", xbmc.LOGINFO)
        f = xbmcvfs.File(url)
        try:
            data = f.read()
        finally:
            f.close()
        
        if data and len(data) > 0:
            result = data.decode("utf-8", "ignore") if isinstance(data, bytes) else data
            msg = f"HTTP uspjesno (bez headera) - duzina: {len(result)} bytes"
            xbmc.log(f"[AmKo] {msg}", xbmc.LOGINFO)
            debug_log(msg)
            return result
    except Exception as e:
        msg = f"Pokusaj 2 neuspio: {str(e)}"
        xbmc.log(f"[AmKo] {msg}", xbmc.LOGWARNING)
        debug_log(msg, "WARN")
    
    # Pokušaj 3: Python urllib ako je dostupan (Windows, neki Android)
    try:
        xbmc.log(f"[AmKo] Pokusaj 3: urllib.request", xbmc.LOGINFO)
        
        req = urllib.request.Request(url)
        if headers:
            for k, v in headers.items():
                req.add_header(k, v)
        
        response = urllib.request.urlopen(req, timeout=15)
        data = response.read()
        result = data.decode("utf-8", "ignore")
        xbmc.log(f"[AmKo] HTTP uspjesno (urllib) - duzina: {len(result)} bytes", xbmc.LOGINFO)
        return result
    except Exception as e:
        xbmc.log(f"[AmKo] Pokusaj 3 neuspio: {str(e)}", xbmc.LOGWARNING)
    
    # Svi pokušaji neuspjeli
    error_msg = f"[AmKo] SVI HTTP POKUSAJI NEUSPJELI za: {url}"
    xbmc.log(error_msg, xbmc.LOGERROR)
    return None  # Vrati None umjesto da bacam exception

def http_get_with_final_url(url, headers=None, timeout=15):
    """HTTP GET koji vraća i finalni URL (poslije redirecta)"""
    try:
        req = urllib.request.Request(url)
        if headers:
            for k, v in headers.items():
                req.add_header(k, v)
        response = urllib.request.urlopen(req, timeout=timeout)
        data = response.read()
        text = data.decode("utf-8", "ignore")
        final_url = response.geturl() if hasattr(response, "geturl") else url
        return text, final_url
    except Exception:
        pass

    data = http_get(url, headers=headers)
    return data, url

def safe_json_loads(data):
    """Pojednostavljen JSON parser sa osnovnom sanitizacijom"""
    if isinstance(data, bytes):
        data = data.decode("utf-8", "ignore")
    if not isinstance(data, str):
        data = str(data)

    def _repair_config_json_text(s):
        # Wrap multiple URL strings into an array when missing brackets
        s = re.sub(
            r'"url"\s*:\s*((?:"[^\"]*"\s*,\s*)+"[^\"]*")',
            lambda m: '"url": [' + m.group(1) + ']'
            if re.search(r'"\s*,\s*"', m.group(1))
            else '"url": ' + m.group(1),
            s,
        )
        return s

    def _extract_m3u_lists(text):
        lists = []
        m = re.search(r'"m3u_lists"\s*:\s*\[', text, flags=re.IGNORECASE)
        if not m:
            return lists
        start = m.end()
        end_match = re.search(r'"mac_portals"\s*:', text[start:], flags=re.IGNORECASE)
        end = start + end_match.start() if end_match else len(text)
        block = text[start:end]

        for name_match in re.finditer(r'"name"\s*:\s*"([^\"]+)"', block, flags=re.IGNORECASE):
            name = name_match.group(1).strip()
            sub = block[name_match.end():]
            next_name = re.search(r'"name"\s*:', sub, flags=re.IGNORECASE)
            segment = sub[:next_name.start()] if next_name else sub
            urls = re.findall(r'"(https?://[^\"]+)"', segment, flags=re.IGNORECASE)
            if not urls:
                urls = re.findall(r'"(http[^\"]+)"', segment, flags=re.IGNORECASE)
            if urls:
                lists.append({"name": name, "url": urls})
        return lists

    def _extract_mac_portals(text):
        portals = []
        m = re.search(r'"mac_portals"\s*:\s*\[', text, flags=re.IGNORECASE)
        if not m:
            return portals
        block = text[m.end():]
        for name_match in re.finditer(r'"name"\s*:\s*"([^\"]+)"', block, flags=re.IGNORECASE):
            name = name_match.group(1).strip()
            sub = block[name_match.end():]
            next_name = re.search(r'"name"\s*:', sub, flags=re.IGNORECASE)
            segment = sub[:next_name.start()] if next_name else sub
            portal_match = re.search(r'"portal"\s*:\s*"([^\"]+)"', segment, flags=re.IGNORECASE)
            if not portal_match:
                portal_match = re.search(r'"(https?://[^\"]+)"', segment, flags=re.IGNORECASE)
            portal = portal_match.group(1).strip() if portal_match else None

            macs = []
            for mac in re.findall(r'([0-9A-Fa-f]{2}(?::[0-9A-Fa-f]{2}){5})', segment):
                mac_up = mac.upper()
                if mac_up not in macs:
                    macs.append(mac_up)

            if name and portal and macs:
                portals.append({"name": name, "portal": portal, "macs": macs})
        return portals

    def _extract_config_fallback(text):
        if "m3u_lists" not in text and "mac_portals" not in text:
            return None
        lists = _extract_m3u_lists(text)
        portals = _extract_mac_portals(text)
        if lists or portals:
            return {"m3u_lists": lists, "mac_portals": portals}
        return None

    def _sanitize(s):
        # Strip BOM i whitespace
        s = s.lstrip("\ufeff").strip()
        # Zamijeni TAB znakove (JSON ih ne dozvoljava u stringovima)
        s = s.replace("\t", " ")
        # Ukloni komentare (// ili /* */) - preskočeno zbog URL-ova (http://)
        # Popravi ne-escaped \n/\r unutar stringova
        out = []
        in_string = False
        escape = False
        for ch in s:
            if in_string:
                if escape:
                    out.append(ch)
                    escape = False
                elif ch == "\\":
                    out.append(ch)
                    escape = True
                elif ch == '"':
                    out.append(ch)
                    in_string = False
                elif ch in "\r\n":
                    out.append(" ")
                else:
                    out.append(ch)
            else:
                if ch == '"':
                    in_string = True
                out.append(ch)
        s = "".join(out)
        # Ukloni control karaktere (osim \t, \n, \r)
        s = re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f]", "", s)
        # Ukloni trailing commas prije } ili ]
        s = re.sub(r",\s*(\}|\])", r"\1", s)
        return s

    s = _sanitize(data)

    try:
        return json.loads(s)
    except json.JSONDecodeError as e:
        # Loguj tačan kontekst greške
        try:
            start = max(e.pos - 80, 0)
            end = min(e.pos + 80, len(s))
            context = s[start:end].replace("\n", " ").replace("\r", " ")
            xbmc.log(
                f"[AmKo] JSON parse greska: {e.msg} (line {e.lineno}, col {e.colno}) | kontekst: {context}",
                xbmc.LOGERROR,
            )
        except Exception:
            xbmc.log(f"[AmKo] JSON parse greska: {str(e)}", xbmc.LOGERROR)

        # Pokušaj popravke specifične za poznati config format
        try:
            repaired = _repair_config_json_text(s)
            if repaired and repaired != s:
                return json.loads(repaired)
        except Exception:
            pass

        # Pokušaj ekstraktovati JSON iz odgovora
        obj_start = s.find("{")
        obj_end = s.rfind("}")
        if obj_start != -1 and obj_end != -1 and obj_end > obj_start:
            candidate = _sanitize(s[obj_start:obj_end + 1])
            try:
                return json.loads(candidate)
            except Exception:
                pass

        # Fallback: ručno izvuci m3u_lists i mac_portals iz neispravnog JSON-a
        try:
            fallback = _extract_config_fallback(s)
            if fallback:
                return fallback
        except Exception:
            pass

        # Fallback: pokušaj Python literal (podržava 'single quotes')
        try:
            py = s
            py = re.sub(r"\btrue\b", "True", py, flags=re.IGNORECASE)
            py = re.sub(r"\bfalse\b", "False", py, flags=re.IGNORECASE)
            py = re.sub(r"\bnull\b", "None", py, flags=re.IGNORECASE)
            return ast.literal_eval(py)
        except Exception:
            pass
        raise
    except Exception as e:
        xbmc.log(f"[AmKo] JSON parse greska: {str(e)}", xbmc.LOGERROR)
        raise

def _normalize_url(value):
    if not isinstance(value, str):
        return value
    v = value.strip()
    if v.lower().startswith("http"):
        v = re.sub(r"\s+", "", v)
        v = re.sub(r"^(https?):/(?!/)", r"\1://", v)
    return v

def _is_valid_url(value):
    if not isinstance(value, str):
        return False
    v = value.strip()
    return bool(re.match(r"^https?://[^/]+", v, flags=re.IGNORECASE))

def normalize_config(cfg):
    if not isinstance(cfg, dict):
        return cfg

    out = dict(cfg)

    m3u_lists = []
    for item in (cfg.get("m3u_lists") or []):
        if not isinstance(item, dict):
            continue
        name = item.get("name") or "Lista"
        url = item.get("url")
        if isinstance(url, list):
            cleaned = [_normalize_url(u) for u in url if isinstance(u, str) and u.strip()]
            cleaned = [u for u in cleaned if _is_valid_url(u)]
            if not cleaned:
                continue
            url = cleaned
        else:
            url = _normalize_url(url) if isinstance(url, str) else url
            if not url or not _is_valid_url(url):
                continue
        m3u_lists.append({"name": name, "url": url})

    mac_portals = []
    for item in (cfg.get("mac_portals") or []):
        if not isinstance(item, dict):
            continue
        name = item.get("name") or "MAC"
        portal = _normalize_url(item.get("portal"))
        macs = item.get("macs") or []
        if isinstance(macs, str):
            macs = [m.strip() for m in macs.split(",") if m.strip()]
        macs_clean = []
        for mac in macs:
            nmac = normalize_mac(mac) if isinstance(mac, str) else None
            if nmac and nmac not in macs_clean:
                macs_clean.append(nmac)
        if portal and _is_valid_url(portal) and macs_clean:
            mac_portals.append({"name": name, "portal": portal, "macs": macs_clean})

    out["m3u_lists"] = m3u_lists
    out["mac_portals"] = mac_portals
    return out

def _pick_first_valid_url(value):
    if isinstance(value, list):
        for u in value:
            nu = _normalize_url(u)
            if _is_valid_url(nu):
                return nu
        return None
    nu = _normalize_url(value) if isinstance(value, str) else value
    return nu if _is_valid_url(nu) else None

def _is_playlist_url(url):
    if not isinstance(url, str):
        return False
    lower = url.lower().strip()
    return lower.endswith(".m3u") or lower.endswith(".m3u8")

def _resolve_playlist_url(url):
    if not url:
        return None
    data, final_url = http_get_with_final_url(url)
    if not data:
        return None
    lines = [ln.strip() for ln in data.splitlines() if ln.strip()]
    if not lines:
        return None

    target = None
    has_extinf = False
    found_variant = False
    i = 0
    while i < len(lines):
        line = lines[i]
        if line.startswith("#"):
            if line.upper().startswith("#EXTINF"):
                has_extinf = True
            if line.upper().startswith("#EXT-X-STREAM-INF"):
                j = i + 1
                while j < len(lines) and lines[j].startswith("#"):
                    j += 1
                if j < len(lines):
                    target = lines[j]
                    found_variant = True
                    break
            i += 1
            continue
        target = line
        break

    if found_variant and target:
        return urllib.parse.urljoin(final_url, target)
    if has_extinf:
        return final_url
    if target:
        return urllib.parse.urljoin(final_url, target)
    return None

def _format_m3u_label(name, url, index=None, total=None):
    if index is not None and total and total > 1:
        return f"{name} ({index}/{total})"
    return name

def load_custom_sources():
    default = {"m3u_lists": [], "mac_portals": []}
    try:
        if not xbmcvfs.exists(CUSTOM_FILE):
            return default
        f = xbmcvfs.File(CUSTOM_FILE)
        try:
            content = f.read()
            if isinstance(content, bytes):
                content = content.decode("utf-8", "ignore")
            data = safe_json_loads(content)
            if not isinstance(data, dict):
                return default
            return normalize_config(data)
        finally:
            f.close()
    except Exception:
        return default

def save_custom_sources(data):
    try:
        if not xbmcvfs.exists(PROFILE_PATH):
            xbmcvfs.mkdirs(PROFILE_PATH)
        payload = normalize_config(data if isinstance(data, dict) else {})
        f = xbmcvfs.File(CUSTOM_FILE, "w")
        try:
            f.write(json.dumps(payload, ensure_ascii=False).encode("utf-8"))
        finally:
            f.close()
        return True
    except Exception:
        return False

def merge_with_custom(cfg):
    base = normalize_config(cfg if isinstance(cfg, dict) else {})
    custom = load_custom_sources()
    merged = {
        "m3u_lists": list(base.get("m3u_lists") or []),
        "mac_portals": list(base.get("mac_portals") or []),
    }
    merged["m3u_lists"].extend(custom.get("m3u_lists") or [])
    merged["mac_portals"].extend(custom.get("mac_portals") or [])
    return normalize_config(merged)

# -------------------------------------------------
# CONFIG CACHE
# -------------------------------------------------
def _read_cached_config():
    """Čita cache samo ako nije istekao"""
    try:
        if not xbmcvfs.exists(CACHE_FILE):
            xbmc.log("[AmKo] Cache file ne postoji", xbmc.LOGINFO)
            return None
            
        f = xbmcvfs.File(CACHE_FILE)
        try:
            content = f.read()
            if isinstance(content, bytes):
                content = content.decode("utf-8", "ignore")
            payload = safe_json_loads(content)
            ts = int(payload.get("ts", 0))
            data = payload.get("data", {})
            
            age = time.time() - ts
            if age < CONFIG_TTL:
                xbmc.log(f"[AmKo] Koristi cache (star {int(age)}s)", xbmc.LOGINFO)
                return normalize_config(data)
            else:
                xbmc.log(f"[AmKo] Cache istekao (star {int(age)}s)", xbmc.LOGINFO)
                return None
        finally:
            f.close()
    except Exception as e:
        xbmc.log(f"[AmKo] Greska citanja cache: {str(e)}", xbmc.LOGWARNING)
    return None

def _write_cached_config(data):
    """Sprema config u cache"""
    try:
        if not xbmcvfs.exists(PROFILE_PATH):
            xbmcvfs.mkdirs(PROFILE_PATH)
        
        payload = {"ts": int(time.time()), "data": data}
        json_str = json.dumps(payload, ensure_ascii=False)
        
        f = xbmcvfs.File(CACHE_FILE, "w")
        try:
            if isinstance(json_str, str):
                f.write(json_str.encode("utf-8"))
            else:
                f.write(json_str)
            xbmc.log("[AmKo] Cache uspjesno spremljen", xbmc.LOGINFO)
        finally:
            f.close()
    except Exception as e:
        xbmc.log(f"[AmKo] Greska spremanja cache: {str(e)}", xbmc.LOGWARNING)

# -------------------------------------------------
# PARAMS
# -------------------------------------------------
def get_params():
    if len(sys.argv) < 3:
        return {}
    return dict(urllib.parse.parse_qsl(sys.argv[2][1:]))

# -------------------------------------------------
# ADD ITEMS
# -------------------------------------------------
def add_dir(label, action, **kwargs):
    url = BASE_URL + "?action=" + action
    for k, v in kwargs.items():
        url += "&{}={}".format(k, urllib.parse.quote_plus(str(v)))

    li = xbmcgui.ListItem(label)
    apply_art(li)
    xbmcplugin.addDirectoryItem(ADDON_HANDLE, url, li, True)

def add_playable(label, action, **kwargs):
    url = BASE_URL + "?action=" + action
    for k, v in kwargs.items():
        url += "&{}={}".format(k, urllib.parse.quote_plus(str(v)))

    li = xbmcgui.ListItem(label)
    li.setProperty("IsPlayable", "true")
    apply_art(li)
    xbmcplugin.addDirectoryItem(ADDON_HANDLE, url, li, False)

# -------------------------------------------------
# CONFIG
# -------------------------------------------------
def load_config():
    """Učitava config sa servera, koristi cache samo ako je svjež"""
    debug_log("=== POCINJE UCITAVANJE KONFIGURACIJE ===")
    xbmc.log("[AmKo] === POCINJE UCITAVANJE KONFIGURACIJE ===", xbmc.LOGINFO)
    xbmc.log(f"[AmKo] Kodi verzija: {xbmc.getInfoLabel('System.BuildVersion')}", xbmc.LOGINFO)
    xbmc.log(f"[AmKo] Platform: {xbmc.getInfoLabel('System.OSVersionInfo')}", xbmc.LOGINFO)
    
    # Provjeri cache SAMO ako nije istekao
    cached = _read_cached_config()
    if cached:
        xbmc.log("[AmKo] Koristim vazeci cache", xbmc.LOGINFO)
        return cached
    
    # Cache istekao ili ne postoji - učitaj sa servera
    xbmc.log(f"[AmKo] Ucitavam sa servera: {CONFIG_URL}", xbmc.LOGINFO)
    
    # Prvo pokušaj bez headera (najjednostavnije)
    try:
        xbmc.log("[AmKo] Pokusaj ucitavanja BEZ headera...", xbmc.LOGINFO)
        debug_log("Pokusaj ucitavanja BEZ headera...")
        data = http_get(CONFIG_URL, headers=None)
        
        if not data or len(data) < 10:
            error_msg = f"Prazan odgovor (duzina: {len(data) if data else 0})"
            debug_log(error_msg, "ERROR")
            raise Exception(error_msg)
        
        xbmc.log(f"[AmKo] Primljen odgovor, duzina: {len(data)}", xbmc.LOGINFO)
        debug_log(f"Primljen odgovor, duzina: {len(data)}")
        
        # Log prvih 200 karaktera za debugging
        preview = data[:200].replace('\n', ' ').replace('\r', '')
        xbmc.log(f"[AmKo] Preview: {preview}...", xbmc.LOGINFO)
        
        parsed = normalize_config(safe_json_loads(data))
        
        # Provjeri da li je config validan
        if not isinstance(parsed, dict):
            raise Exception(f"Config nije dict, tip: {type(parsed)}")
        
        m3u_lists = parsed.get("m3u_lists", [])
        mac_portals = parsed.get("mac_portals", [])
        
        if not m3u_lists and not mac_portals:
            raise Exception("Config je prazan - nema m3u_lists ni mac_portals")
        
        m3u_count = len(m3u_lists)
        mac_count = len(mac_portals)
        success_msg = f"Config uspjesno parsiran: {m3u_count} M3U, {mac_count} MAC"
        xbmc.log(f"[AmKo] {success_msg}", xbmc.LOGINFO)
        debug_log(success_msg)
        
        _write_cached_config(parsed)
        return parsed
        
    except Exception as e:
        error_msg = f"GRESKA ucitavanja config: {str(e)}"
        xbmc.log(f"[AmKo] {error_msg}", xbmc.LOGERROR)
        debug_log(error_msg, "ERROR")
        import traceback
        tb_msg = traceback.format_exc()
        xbmc.log(f"[AmKo] Traceback: {tb_msg}", xbmc.LOGERROR)
        debug_log(f"Traceback: {tb_msg}", "ERROR")
        
        # Pokušaj koristiti stari cache ako postoji
        try:
            if xbmcvfs.exists(CACHE_FILE):
                xbmc.log("[AmKo] Koristim stari cache kao fallback", xbmc.LOGWARNING)
                f = xbmcvfs.File(CACHE_FILE)
                try:
                    content = f.read()
                    if isinstance(content, bytes):
                        content = content.decode("utf-8", "ignore")
                    payload = safe_json_loads(content)
                    old_data = normalize_config(payload.get("data", {}))
                    if old_data and (old_data.get("m3u_lists") or old_data.get("mac_portals")):
                        xbmc.log("[AmKo] Stari cache ima podatke - koristim ga", xbmc.LOGINFO)
                        return old_data
                finally:
                    f.close()
        except Exception as e2:
            xbmc.log(f"[AmKo] Greska citanja starog cache: {str(e2)}", xbmc.LOGERROR)
        
        xbmc.log("[AmKo] Vracam prazan config", xbmc.LOGERROR)
        return {"m3u_lists": [], "mac_portals": []}

def _ask_text(title, default_text=""):
    kb = xbmc.Keyboard(default_text, title)
    kb.doModal()
    if kb.isConfirmed():
        return kb.getText().strip()
    return None

def add_custom_m3u():
    name = _ask_text("Naziv M3U liste", "Moja M3U")
    if name is None:
        return
    if not name:
        name = "Moja M3U"

    url = _ask_text("M3U URL (http/https)")
    if url is None:
        return
    url = _normalize_url(url)
    if not _is_valid_url(url):
        xbmcgui.Dialog().notification("AmKo IPTV", "Neispravan M3U URL", xbmcgui.NOTIFICATION_ERROR)
        return

    custom = load_custom_sources()
    lists = list(custom.get("m3u_lists") or [])
    updated = False
    for item in lists:
        if _pick_first_valid_url(item.get("url")) == url:
            item["name"] = name
            updated = True
            break
    if not updated:
        lists.append({"name": name, "url": url})

    custom["m3u_lists"] = lists
    if save_custom_sources(custom):
        xbmcgui.Dialog().notification("AmKo IPTV", "M3U lista spremljena", xbmcgui.NOTIFICATION_INFO)
    else:
        xbmcgui.Dialog().notification("AmKo IPTV", "Greška pri spremanju", xbmcgui.NOTIFICATION_ERROR)

def add_custom_mac():
    name = _ask_text("Naziv MAC portala", "Moj MAC")
    if name is None:
        return
    if not name:
        name = "Moj MAC"

    portal = _ask_text("Portal URL (http/https)")
    if portal is None:
        return
    portal = _normalize_url(portal)
    if not _is_valid_url(portal):
        xbmcgui.Dialog().notification("AmKo IPTV", "Neispravan portal URL", xbmcgui.NOTIFICATION_ERROR)
        return

    macs_raw = _ask_text("MAC adrese (odvojene zarezom)", "00:1A:79:00:00:00")
    if macs_raw is None:
        return

    macs = []
    for part in macs_raw.split(","):
        nm = normalize_mac(part)
        if nm and nm not in macs:
            macs.append(nm)

    if not macs:
        xbmcgui.Dialog().notification("AmKo IPTV", "Nema ispravnih MAC adresa", xbmcgui.NOTIFICATION_ERROR)
        return

    custom = load_custom_sources()
    portals = list(custom.get("mac_portals") or [])
    updated = False
    for item in portals:
        if _pick_first_valid_url(item.get("portal")) == portal:
            item["name"] = name
            item["macs"] = macs
            updated = True
            break
    if not updated:
        portals.append({"name": name, "portal": portal, "macs": macs})

    custom["mac_portals"] = portals
    if save_custom_sources(custom):
        xbmcgui.Dialog().notification("AmKo IPTV", "MAC portal spremljen", xbmcgui.NOTIFICATION_INFO)
    else:
        xbmcgui.Dialog().notification("AmKo IPTV", "Greška pri spremanju", xbmcgui.NOTIFICATION_ERROR)

# -------------------------------------------------
# ROOT
# -------------------------------------------------
def main_menu():
    add_dir("📺 M3U liste", "m3u_root")
    add_dir("🖥️ MAC portali", "mac_root")
    add_dir("➕ Dodaj svoju M3U listu", "add_custom_m3u")
    add_dir("➕ Dodaj svoj MAC portal", "add_custom_mac")
    add_dir("🔧 Dijagnostika", "show_debug")
    xbmcplugin.setContent(ADDON_HANDLE, "videos")
    xbmcplugin.endOfDirectory(ADDON_HANDLE, cacheToDisc=True)

# -------------------------------------------------
# M3U
# -------------------------------------------------
def m3u_root(cfg):
    lists = cfg.get("m3u_lists", [])
    xbmc.log(f"[AmKo] M3U root: {len(lists)} listi", xbmc.LOGINFO)
    
    if not lists:
        debug_log("M3U liste nisu ucitane!", "ERROR")
        xbmc.log("[AmKo] M3U liste nisu ucitane!", xbmc.LOGERROR)
        try:
            xbmcgui.Dialog().notification(
                "AmKo IPTV",
                "Greška pri učitavanju - provjerite log",
                xbmcgui.NOTIFICATION_ERROR,
                5000
            )
        except Exception as e:
            xbmc.log(f"[AmKo] Greska pri prikazivanju notifikacije: {e}", xbmc.LOGERROR)
        xbmcplugin.endOfDirectory(ADDON_HANDLE, cacheToDisc=False)
        return
        
    for m in lists:
        name = m.get("name", "Lista")
        url_value = m.get("url")
        if isinstance(url_value, list):
            valid_urls = [u for u in (_normalize_url(x) for x in url_value) if _is_valid_url(u)]
            total = len(valid_urls)
            for idx, u in enumerate(valid_urls, start=1):
                label = "📺 " + _format_m3u_label(name, u, idx, total)
                add_dir(label, "open_m3u", url=u)
        else:
            url = _pick_first_valid_url(url_value)
            if not url:
                continue
            label = "📺 " + _format_m3u_label(name, url)
            add_dir(label, "open_m3u", url=url)
    
    xbmcplugin.setContent(ADDON_HANDLE, "videos")
    xbmcplugin.endOfDirectory(ADDON_HANDLE, cacheToDisc=True)

def open_m3u(url):
    # Parse M3U and present groups (countries) first; fallback to flat list
    data = http_get(url)
    
    if not data:
        xbmc.log(f"[AmKo] Greska: Nije moguće učitati M3U sa {url}", xbmc.LOGERROR)
        try:
            xbmcgui.Dialog().notification("AmKo IPTV", "Greška pri učitavanju M3U", xbmcgui.NOTIFICATION_ERROR)
        except Exception:
            pass
        xbmcplugin.endOfDirectory(ADDON_HANDLE, cacheToDisc=False)
        return
    
    entries = parse_m3u_entries(data, base_url=url)

    if not entries:
        # Fallback to original flat behavior
        name = None
        for line in data.splitlines():
            if line.startswith("#EXTINF"):
                name = line.split(",")[-1].strip()
            elif name and line and not line.startswith("#"):
                play_url = line.strip()
                if "://" not in play_url:
                    play_url = urllib.parse.urljoin(url, play_url)
                li = xbmcgui.ListItem(name)
                li.setProperty("IsPlayable", "true")
                if _is_playlist_url(play_url):
                    play_action = BASE_URL + "?action=play_m3u&url=" + urllib.parse.quote_plus(play_url)
                else:
                    play_action = BASE_URL + "?action=play_m3u_entry&url=" + urllib.parse.quote_plus(play_url)
                xbmcplugin.addDirectoryItem(ADDON_HANDLE, play_action, li, False)
                name = None
        xbmcplugin.setContent(ADDON_HANDLE, "videos")
        xbmcplugin.endOfDirectory(ADDON_HANDLE, cacheToDisc=True)
        return

    groups = {}
    for e in entries:
        g = e.get("group") or "Ostalo"
        groups.setdefault(g, []).append(e)

    for g in sorted(groups.keys(), key=lambda s: s.lower()):
        add_dir("📺 " + g, "open_m3u_group", url=url, group=g)
    xbmcplugin.setContent(ADDON_HANDLE, "videos")
    xbmcplugin.endOfDirectory(ADDON_HANDLE, cacheToDisc=True)

def open_m3u_group(url, group):
    data = http_get(url)
    
    if not data:
        xbmc.log(f"[AmKo] Greska: Nije moguće učitati M3U sa {url}", xbmc.LOGERROR)
        try:
            xbmcgui.Dialog().notification("AmKo IPTV", "Greška pri učitavanju M3U", xbmcgui.NOTIFICATION_ERROR)
        except Exception:
            pass
        xbmcplugin.endOfDirectory(ADDON_HANDLE, cacheToDisc=False)
        return
    
    entries = [e for e in parse_m3u_entries(data, base_url=url) if (e.get("group") or "Ostalo") == group]
    entries.sort(key=lambda e: e["name"].lower())
    for e in entries:
        li = xbmcgui.ListItem(e["name"])
        li.setProperty("IsPlayable", "true")
        li.setInfo("video", {"title": e["name"], "mediatype": "video"})
        apply_art(li)
        play_url = e["url"]
        if _is_playlist_url(play_url):
            play_action = BASE_URL + "?action=play_m3u&url=" + urllib.parse.quote_plus(play_url)
        else:
            play_action = BASE_URL + "?action=play_m3u_entry&url=" + urllib.parse.quote_plus(play_url)
        xbmcplugin.addDirectoryItem(ADDON_HANDLE, play_action, li, False)
    xbmcplugin.addSortMethod(ADDON_HANDLE, xbmcplugin.SORT_METHOD_LABEL)
    xbmcplugin.setContent(ADDON_HANDLE, "videos")
    xbmcplugin.endOfDirectory(ADDON_HANDLE, cacheToDisc=True)

def play_m3u(url):
    resolved = _resolve_playlist_url(url) if _is_playlist_url(url) else url
    if not resolved:
        resolved = url
    if not resolved:
        xbmc.log(f"[AmKo] Greska: Nije moguće resolve-ati M3U {url}", xbmc.LOGERROR)
        try:
            xbmcgui.Dialog().notification("AmKo IPTV", "Greška pri pokretanju", xbmcgui.NOTIFICATION_ERROR)
        except Exception:
            pass
        return
    li = xbmcgui.ListItem(path=resolved)
    li.setProperty("IsPlayable", "true")
    xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, li)

def play_m3u_entry(url):
    if _is_playlist_url(url):
        play_m3u(url)
        return
    li = xbmcgui.ListItem(path=url)
    li.setProperty("IsPlayable", "true")
    xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, li)

# -------------------------------------------------
# MAC / STALKER
# -------------------------------------------------
def mac_root(cfg):
    portals = cfg.get("mac_portals", [])
    xbmc.log(f"[AmKo] MAC root: {len(portals)} portala", xbmc.LOGINFO)
    
    if not portals:
        xbmc.log("[AmKo] MAC portali nisu ucitani!", xbmc.LOGERROR)
        try:
            xbmcgui.Dialog().notification(
                "AmKo IPTV",
                "Greška pri učitavanju - provjerite log",
                xbmcgui.NOTIFICATION_ERROR,
                5000
            )
        except Exception as e:
            xbmc.log(f"[AmKo] Greska pri prikazivanju notifikacije: {e}", xbmc.LOGERROR)
        xbmcplugin.endOfDirectory(ADDON_HANDLE, cacheToDisc=False)
        return
        
    for p in portals:
        portal_url = _pick_first_valid_url(p.get("portal"))
        if not portal_url:
            continue
        add_dir(
            "🖥️ " + p["name"],
            "mac_groups",
            portal=portal_url,
            macs=",".join(p["macs"])
        )
    xbmcplugin.setContent(ADDON_HANDLE, "videos")
    xbmcplugin.endOfDirectory(ADDON_HANDLE, cacheToDisc=True)

def mac_groups(portal, macs):
    """Show country groups for MAC portal"""
    channels_data = None
    working_mac = None
    working_token = None
    
    for mac in macs.split(","):
        nmac = normalize_mac(mac)
        if not nmac:
            xbmc.log(f"Neispravna MAC adresa: {mac}", xbmc.LOGERROR)
            continue
        try:
            token = stalker_handshake(portal, nmac)
            channels = stalker_channels(portal, nmac, token)
            if channels:
                channels_data = channels
                working_mac = nmac
                working_token = token
                break
        except Exception as e:
            xbmc.log(str(e), xbmc.LOGERROR)
    
    if not channels_data:
        xbmcgui.Dialog().notification(
            "AmKo IPTV",
            "Nijedan MAC ne radi",
            xbmcgui.NOTIFICATION_ERROR
        )
        xbmcplugin.endOfDirectory(ADDON_HANDLE)
        return
    
    # Group channels by country/group
    groups = {}
    for ch in channels_data:
        group = extract_country_from_name(ch.get("name", ""))
        groups.setdefault(group, []).append(ch)
    
    for g in sorted(groups.keys(), key=lambda s: s.lower()):
        add_dir(
            "📺 " + g,
            "mac_channels",
            portal=portal,
            mac=working_mac,
            token=working_token,
            group=g
        )
    xbmcplugin.setContent(ADDON_HANDLE, "videos")
    xbmcplugin.endOfDirectory(ADDON_HANDLE, cacheToDisc=True)

def stalker_headers(portal, mac, token=None):
    h = {
        "User-Agent": "Mozilla/5.0 (QtEmbedded; U; Linux; en) AppleWebKit/533.3 (KHTML, like Gecko) MAG200/2.12.33 Safari/533.3",
        "X-User-Agent": "Model: MAG254; Link: Ethernet",
        "Referer": portal + "/c/",
        "Accept": "*/*",
        "Cookie": f"mac={mac}; stb_lang=en; timezone=Europe/Berlin"
    }
    if token:
        h["Authorization"] = "Bearer " + token
    return h

def stalker_handshake(portal, mac):
    http_get(portal + "/c/", {"Cookie": f"mac={mac}"})
    resp = http_get(
        f"{portal}/portal.php?action=handshake&type=stb&mac={mac}",
        stalker_headers(portal, mac)
    )
    if not resp:
        raise Exception("Handshake nije uspio")
    data = json.loads(resp)
    return data["js"]["token"]

def stalker_channels(portal, mac, token):
    resp = http_get(
        f"{portal}/portal.php?action=get_all_channels&type=itv&mac={mac}",
        stalker_headers(portal, mac, token)
    )
    if not resp:
        return []
    data = json.loads(resp)
    if isinstance(data, list):
        return data
    if isinstance(data, dict):
        return data.get("js", {}).get("data", [])
    return []

def stalker_create_link(portal, mac, token, cmd):
    cmd = cmd.strip()
    if cmd.lower().startswith("ffmpeg "):
        cmd = cmd[7:].strip()
    data = json.loads(http_get(
        f"{portal}/portal.php?action=create_link&type=itv&cmd={urllib.parse.quote(cmd)}&mac={mac}",
        stalker_headers(portal, mac, token)
    ))
    out_cmd = data["js"]["cmd"].strip()
    if out_cmd.lower().startswith("ffmpeg "):
        out_cmd = out_cmd[7:].strip()
    parts = out_cmd.split()
    stream = next((p for p in parts if "://" in p), out_cmd)
    return stream

def normalize_mac(mac):
    s = mac.strip().upper().replace('-', ':').replace(' ', '')
    # If it's 12 hex chars without separators, insert colons
    hexchars = ''.join(ch for ch in s if ch in '0123456789ABCDEF')
    if len(hexchars) == 12:
        s = ':'.join(hexchars[i:i+2] for i in range(0, 12, 2))
    if re.fullmatch(r'([0-9A-F]{2}:){5}[0-9A-F]{2}', s):
        return s
    return None

def mac_channels(portal, mac, token, group):
    """Show channels from specific group"""
    try:
        channels = stalker_channels(portal, mac, token)
        if not channels:
            xbmcplugin.endOfDirectory(ADDON_HANDLE)
            return
        
        # Filter by group
        filtered = [ch for ch in channels if extract_country_from_name(ch.get("name", "")) == group]
        filtered.sort(key=lambda ch: ch.get("name", "").lower())
        
        for ch in filtered:
            cmd = ch.get("cmd")
            if not cmd:
                continue
            
            url = BASE_URL + "?action=mac_play"
            url += "&portal=" + urllib.parse.quote_plus(portal)
            url += "&mac=" + urllib.parse.quote_plus(mac)
            url += "&token=" + urllib.parse.quote_plus(token)
            url += "&cmd=" + urllib.parse.quote_plus(cmd)
            
            li = xbmcgui.ListItem(ch.get("name", "Unknown"))
            li.setProperty("IsPlayable", "true")
            li.setInfo("video", {"title": ch.get("name", "Unknown"), "mediatype": "video"})
            apply_art(li)
            xbmcplugin.addDirectoryItem(ADDON_HANDLE, url, li, False)
        
        xbmcplugin.addSortMethod(ADDON_HANDLE, xbmcplugin.SORT_METHOD_LABEL)
        xbmcplugin.setContent(ADDON_HANDLE, "videos")
        xbmcplugin.endOfDirectory(ADDON_HANDLE, cacheToDisc=True)
        
    except Exception as e:
        xbmc.log(str(e), xbmc.LOGERROR)
        xbmcplugin.endOfDirectory(ADDON_HANDLE)

def mac_play(portal, mac, token, cmd):
    stream = stalker_create_link(portal, mac, token, cmd)
    li = xbmcgui.ListItem(path=stream)
    li.setProperty("IsPlayable", "true")
    xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, li)

# -------------------------------------------------
# M3U Helpers
# -------------------------------------------------
def extract_country_from_name(name):
    """Extract country/group from channel name"""
    if not name:
        return "Ostalo"
    
    name_upper = name.strip().upper()
    
    # Priority 1: Check for EXYU/Ex-Yugoslavia first (before individual countries)
    if re.search(r'\b(EXYU|EX-YU|EX YU|YUGO|YUGOSLAVIA|BALKAN)\b', name_upper):
        return "EXYU"
    if re.match(r'^\[?(EXYU|EX-YU|YUGO)\]?[:\s|\-]', name_upper):
        return "EXYU"
    
    # Special handling for Bosnia - BiH, BA, BH all map to BA
    if re.match(r'^\[?(BiH|BA|BH)\]?[:\s|\-]', name_upper) or \
       re.match(r'^\((BiH|BA|BH)\)', name_upper) or \
       name_upper.startswith('BiH') or \
       name_upper.startswith('BH_') or \
       name_upper.startswith('BH.') or \
       name_upper.startswith('BA_') or \
       name_upper.startswith('BA.'):
        return "BA"
    
    # Country code patterns - check prefixes first (2-3 letters)
    # Patterns: "HR:", "[HR]", "HR |", "HR-", "(HR)", "AFG:", "ARM:"
    prefix_match = re.match(r'^\[?([A-Z]{2,3})\]?[:\s|\-]', name_upper)
    if prefix_match:
        code = prefix_match.group(1)
        three_map = {"AFG": "AF", "ARM": "AM", "BIH": "BA", "BHR": "BH"}
        if code in three_map:
            return three_map[code]
        if code == "BH":
            return "BA"
        return code[:2]
    
    # Check for (XX) pattern at start
    paren_match = re.match(r'^\(([A-Z]{2,3})\)', name_upper)
    if paren_match:
        code = paren_match.group(1)
        three_map = {"AFG": "AF", "ARM": "AM", "BIH": "BA", "BHR": "BH"}
        if code in three_map:
            return three_map[code]
        if code == "BH":
            return "BA"
        return code[:2]
    
    # Common country keywords
    countries = {
        "HR": ["HRVATSKA", "CROATIA", "CROATIAN", "HRVATSKI"],
        "RS": ["SRBIJA", "SERBIA", "SERBIAN", "SRPSKI"],
        "BA": ["BOSNA", "BOSNIA", "BOSANSKI", "HERCEGOVINA"],
        "SI": ["SLOVENIA", "SLOVENIJA", "SLOVENSKI"],
        "ME": ["CRNA GORA", "MONTENEGRO", "MONTENEGRIN", "CRNOGORSKI"],
        "MK": ["MAKEDONIJA", "MACEDONIA", "MACEDONIAN"],
        "XK": ["KOSOVO", "KOSOVA", "KOSOVSKI"],
        "US": ["USA", "UNITED STATES", "AMERICAN"],
        "UK": ["UNITED KINGDOM", "BRITISH", "ENGLAND"],
        "DE": ["GERMANY", "DEUTSCHLAND", "NJEMACKA", "GERMAN"],
        "IT": ["ITALY", "ITALIA", "ITALIJA", "ITALIAN"],
        "FR": ["FRANCE", "FRANCUSKA", "FRENCH"],
        "ES": ["SPAIN", "ESPANA", "SPANIJA", "SPANISH"],
        "PT": ["PORTUGAL", "PORTUGUESE", "PORTUGALSKI"],
        "TR": ["TURKEY", "TURKIYE", "TURSKA", "TURKISH"],
        "AL": ["ALBANIA", "SHQIPERIA", "ALBANIJA", "ALBANIAN"],
        "GR": ["GREECE", "ELLADA", "GRCKA", "GREEK"],
        "RO": ["ROMANIA", "RUMUNIJA", "ROMANIAN"],
        "BG": ["BULGARIA", "BUGARSKA", "BULGARIAN"],
        "NL": ["NETHERLANDS", "HOLLAND", "DUTCH"],
        "BE": ["BELGIUM", "BELGIJA", "BELGIAN"],
        "AT": ["AUSTRIA", "AUSTRIJA", "AUSTRIAN"],
        "CH": ["SWITZERLAND", "SWISS", "SVICARSKA"],
        "SE": ["SWEDEN", "SVEDSKA", "SWEDISH"],
        "NO": ["NORWAY", "NORVESKA", "NORWEGIAN"],
        "DK": ["DENMARK", "DANSKA", "DANISH"],
        "PL": ["POLAND", "POLSKA", "POLISH"],
        "CZ": ["CZECH", "CESKA", "CZECHIA"],
        "SK": ["SLOVAKIA", "SLOVACKA", "SLOVAK"],
        "HU": ["HUNGARY", "MADJARSKA", "HUNGARIAN"],
        "RU": ["RUSSIA", "RUSIJA", "RUSSIAN"],
        "UA": ["UKRAINE", "UKRAJINA", "UKRAINIAN"],
        "AE": ["UAE", "DUBAI", "EMIRATES"],
        "SA": ["SAUDI", "KSA"],
        "EG": ["EGYPT", "EGIPAT"],
        "MA": ["MOROCCO", "MAROKO"],
        "IN": ["INDIA", "INDIAN", "INDIJA"],
        "PK": ["PAKISTAN", "PAKISTANI"],
        "CN": ["CHINA", "CHINESE", "KINA"],
        "JP": ["JAPAN", "JAPANESE"],
        "KR": ["KOREA", "KOREAN"],
        "AR": ["ARGENTINA", "ARGENTINIAN"],
        "BR": ["BRAZIL", "BRAZILIAN", "BRASIL"],
        "MX": ["MEXICO", "MEXICAN", "MEKSIKO"],
        "CA": ["CANADA", "CANADIAN", "KANADA"],
        "AU": ["AUSTRALIA", "AUSTRALIAN"],
        "IL": ["ISRAEL", "ISRAELI"],
        "IQ": ["IRAQ", "IRAQI"],
        "IR": ["IRAN", "IRANIAN"],
        "AF": ["AFGHANISTAN", "AFGHAN"],
        "LB": ["LEBANON", "LEBANESE"],
        "SY": ["SYRIA", "SYRIAN"],
        "JO": ["JORDAN", "JORDANIAN"],
        "KW": ["KUWAIT", "KUWAITI"],
        "QA": ["QATAR", "QATARI"],
        "BH": ["BAHRAIN", "BAHRAINI"],
        "OM": ["OMAN", "OMANI"],
        "YE": ["YEMEN", "YEMENI"],
        "LY": ["LIBYA", "LIBYAN"],
        "TN": ["TUNISIA", "TUNISIAN"],
        "DZ": ["ALGERIA", "ALGERIAN"],
        "SD": ["SUDAN", "SUDANESE"],
        "SO": ["SOMALIA", "SOMALI"],
        "ET": ["ETHIOPIA", "ETHIOPIAN"],
        "KE": ["KENYA", "KENYAN"],
        "ZA": ["SOUTH AFRICA", "AFRICAN"],
        "NG": ["NIGERIA", "NIGERIAN"],
        "GH": ["GHANA", "GHANAIAN"],
        "TH": ["THAILAND", "THAI"],
        "VN": ["VIETNAM", "VIETNAMESE"],
        "ID": ["INDONESIA", "INDONESIAN"],
        "MY": ["MALAYSIA", "MALAYSIAN"],
        "SG": ["SINGAPORE", "SINGAPOREAN"],
        "PH": ["PHILIPPINES", "FILIPINO"],
        "BD": ["BANGLADESH", "BENGALI"],
        "LK": ["SRI LANKA", "LANKAN"],
        "NP": ["NEPAL", "NEPALESE"],
        "MM": ["MYANMAR", "BURMA"],
        "KH": ["CAMBODIA", "CAMBODIAN"],
        "LA": ["LAOS", "LAOTIAN"],
    }
    
    for code, patterns in countries.items():
        for pattern in patterns:
            if pattern in name_upper:
                return code
    
    # Check for XX_ or XX. patterns
    code_match = re.match(r'^([A-Z]{2,3})[_\.]', name_upper)
    if code_match:
        code = code_match.group(1)
        three_map = {"AFG": "AF", "ARM": "AM", "BIH": "BA", "BHR": "BH"}
        if code in three_map:
            return three_map[code]
        if code == "BH":
            return "BA"
        return code[:2]
    
    return "Ostalo"

def parse_m3u_entries(data, base_url=None):
    entries = []
    current = None
    for line in data.splitlines():
        line = line.strip()
        if not line or line.startswith("#EXTM3U"):
            continue
        if line.startswith("#EXTINF"):
            attrs = {}
            for k, v in re.findall(r'([\w-]+)="([^"]*?)"', line):
                attrs[k.lower()] = v
            name = line.split(",", 1)[-1].strip()
            current = {"name": name, "attrs": attrs}
        elif current and not line.startswith("#"):
            url = line.strip()
            if base_url and "://" not in url:
                url = urllib.parse.urljoin(base_url, url)
            # Priority: group-title > tvg-country > extract from name
            group = current["attrs"].get("group-title") or current["attrs"].get("tvg-country")
            if not group:
                group = extract_country_from_name(current["name"])
            entries.append({
                "name": current["name"],
                "url": url,
                "group": group if group else "Ostalo",
                "attrs": current["attrs"]
            })
            current = None
    return entries

# -------------------------------------------------
# DEBUG / DIJAGNOSTIKA
# -------------------------------------------------
def show_debug():
    """Prikazuje debug informacije"""
    try:
        log_content = get_debug_log()
        
        # Prikaži log kao tekstualni sadržaj
        lines = log_content.split('\n')
        
        # Prikaži samo zadnjih 20 linija
        recent_lines = lines[-20:] if len(lines) > 20 else lines
        display_text = '\n'.join(recent_lines)
        
        try:
            xbmcgui.Dialog().textViewer(
                "AmKo IPTV - Debug Log",
                display_text
            )
        except AttributeError:
            xbmcgui.Dialog().ok("AmKo IPTV - Debug Log", display_text)
    except Exception as e:
        debug_log(f"Greska pri prikazu debug: {str(e)}", "ERROR")
        try:
            xbmcgui.Dialog().notification(
                "AmKo IPTV",
                "Greška pri prikazu debug-a",
                xbmcgui.NOTIFICATION_ERROR
            )
        except Exception:
            pass

# -------------------------------------------------
params = get_params()
cfg = merge_with_custom(load_config())
action = params.get("action")

if action == "m3u_root":
    m3u_root(cfg)
elif action == "open_m3u":
    open_m3u(params["url"])
elif action == "open_m3u_group":
    open_m3u_group(params["url"], params["group"])
elif action == "play_m3u":
    play_m3u(params["url"])
elif action == "play_m3u_entry":
    play_m3u_entry(params["url"])
elif action == "add_custom_m3u":
    add_custom_m3u()
    main_menu()
elif action == "add_custom_mac":
    add_custom_mac()
    main_menu()
elif action == "mac_root":
    mac_root(cfg)
elif action == "mac_groups":
    mac_groups(params["portal"], params["macs"])
elif action == "mac_channels":
    mac_channels(params["portal"], params["mac"], params["token"], params["group"])
elif action == "mac_play":
    mac_play(params["portal"], params["mac"], params["token"], params["cmd"])
elif action == "show_debug":
    show_debug()
else:
    main_menu()
