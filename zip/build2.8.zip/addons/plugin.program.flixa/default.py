import xbmc
import xbmcgui
import sys
import time

# Mapping of keys → add-ons
mapping = {
    "aguiavavoo": {"id": "plugin.video.aguiavavoo", "name": "Aguiavavoo"},
    "elementum": {"id": "plugin.video.elementum", "name": "Elementum"},
    "homelander": {"id": "plugin.video.homelander", "name": "Homelander"},
    "playlistbee": {"id": "plugin.video.playlistbee", "name": "PlaylistBee"},
    "scrubsv2": {"id": "plugin.video.scrubsv2", "name": "Scrubs V2"},
    "sporthdme": {"id": "plugin.video.sporthdme", "name": "SportsHDME"},
    "thecrew": {"id": "plugin.video.thecrew", "name": "The Crew"},
    "umbrella": {"id": "plugin.video.umbrella", "name": "Umbrella"},
    "vavooto": {"id": "plugin.video.vavooto", "name": "Vavoo.to"},
    "daddylive": {"id": "plugin.video.daddylive", "name": "DaddyLive"},
    "amkoiptv": {"id": "plugin.video.amko", "name": "AmkoIptv"},
    "theloop": {"id": "plugin.video.the-loop", "name": "TheLoop"},
    "apexsports": {"id": "plugin.video.apex_sports", "name": "ApexSports"},
    "madtitan": {"id": "plugin.video.madtitansports_apple", "name": "MadTitanSports"},
    "fenlite": {"id": "plugin.video.fenlight", "name": "FenLight"},
    "livetvser": {"id": "plugin.video.livetvSerbia", "name": "LiveTVSerbia"},
    "cosmos": {"id": "plugin.video.cosmos", "name": "Cosmos"},
    "cinebox": {"id": "plugin.video.cinebox", "name": "Cinebox"},
    "gratisred": {"id": "plugin.video.gratisred", "name": "GratisRed"}

}

# Get argument from skin button
key = sys.argv[1] if len(sys.argv) > 1 else None

if key not in mapping:
    xbmcgui.Dialog().ok("Error", "Unknown add-on key")
    exit()

addon_id = mapping[key]["id"]
addon_name = mapping[key]["name"]

# Check if add-on is installed
if xbmc.getCondVisibility(f"System.HasAddon({addon_id})"):
    xbmc.executebuiltin(f"RunAddon({addon_id})")
else:
    install = xbmcgui.Dialog().yesno(
        "Install Add-on",
        f"{addon_name} is not installed.\n\nInstall now?"
    )

    if install:
        xbmc.executebuiltin(f"InstallAddon({addon_id})")
        xbmcgui.Dialog().notification("Installing", addon_name)
        time.sleep(5)  # Give Kodi a few seconds to start installation
        xbmc.executebuiltin(f"RunAddon({addon_id})")